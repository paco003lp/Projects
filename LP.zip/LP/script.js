// Dodavanje u košaricu
function addToCart(name, price) {
  const item = { name, price };
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push(item);
  localStorage.setItem("cart", JSON.stringify(cart));
  alert(`${name} je dodan u košaricu.`);
}

// Prikaz artikala u cart.html
function displayCart() {
  const cartItems = document.getElementById("cart-items");
  const totalPriceEl = document.getElementById("total-price");
  let cart = JSON.parse(localStorage.getItem("cart")) || [];

  if (cartItems) {
    cartItems.innerHTML = "";
    let total = 0;

    cart.forEach((item, index) => {
      const div = document.createElement("div");
      div.classList.add("cart-item");

      div.innerHTML = `
        <div>
          <h4>${item.name}</h4>
          <p>${item.price.toFixed(2)}€</p>
        </div>
        <button onclick="removeFromCart(${index})">Ukloni</button>
      `;

      cartItems.appendChild(div);
      total += item.price;
    });

    totalPriceEl.textContent = `${total.toFixed(2)}€`;
  }
}

// Uklanjanje pojedinog artikla
function removeFromCart(index) {
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.splice(index, 1);
  localStorage.setItem("cart", JSON.stringify(cart));
  displayCart(); // ponovno prikaži
}

// Isprazni cijelu košaricu
function clearCart() {
  if (confirm("Želite li isprazniti košaricu?")) {
    localStorage.removeItem("cart");
    displayCart();
  }
}

// Pretraživanje proizvoda na početnoj
const searchInput = document.getElementById("searchInput");
if (searchInput) {
  searchInput.addEventListener("input", () => {
    const query = searchInput.value.toLowerCase();
    const products = document.querySelectorAll(".product");

    products.forEach((product) => {
      const name = product.dataset.name.toLowerCase();
      product.style.display = name.includes(query) ? "block" : "none";
    });
  });
}

// Pozovi prikaz košarice kad se učita cart.html
document.addEventListener("DOMContentLoaded", () => {
  if (window.location.pathname.includes("cart.html")) {
    displayCart();
  }
});
